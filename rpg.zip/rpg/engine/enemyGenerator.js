class EnemyGenerator {
    constructor(creature, quantity = 7, statuses = [1, 10, 10, 200, 200, 125, 120]) {
        this.creature = creature
        this.quantity = quantity
        this.statuses = statuses
    }
    generateEnemy() {
        const randomStatuses = [...this.statuses]
        randomStatuses[3] = Math.floor(Math.random() * (window.innerHeight - 200));
        randomStatuses[4] = Math.floor(Math.random() * (window.innerHeight - 200));
        const creature = new this.creature(...randomStatuses)
        creature.spawn()
    }
    generateMultipleEnemies(increase = false) {
            let counter = 0;
            while (counter < this.quantity) {
                counter++
                this.generateEnemy()
            }
    }
    conditionalGeneration() {

    }
}

export default EnemyGenerator