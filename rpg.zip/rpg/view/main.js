import Arena from "../arena/arena.js";
import Charmander from "../entities/enemies/charmander/Charmander.js";
import EnemyGenerator from "../engine/enemyGenerator.js"

const arena = new Arena();
const enemeyGenerator = new EnemyGenerator(Charmander, 10)

arena.createArena()
enemeyGenerator.generateMultipleEnemies()