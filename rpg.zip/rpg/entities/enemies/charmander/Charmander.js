class Charmander {
    constructor(hp, def, atk, y, x, height = 125, width = 120) {
        this.hp = hp;
        this.def = def;
        this.atk = atk;
        this.y = y;
        this.x = x;
        this.height = height;
        this.width = width;
    }
    spawn() {
        const arena = document.querySelector(".arena");
        const charmanderElement = document.createElement("img");
        charmanderElement.style.position = "absolute";
        charmanderElement.style.top = this.y + "px";
        charmanderElement.style.left = this.x + "px";
        charmanderElement.style.height = this.height + "px";
        charmanderElement.style.width = this.width + "px";
        charmanderElement.src = "../entities/enemies/charmander/assets/charmander.gif"
        this.createHpBar()
        arena.appendChild(charmanderElement);
        this.detectHit(charmanderElement)
        return charmanderElement;
    }
    createHpBar() {
        const hpContainer = document.createElement("div")
        const hpBar = document.createElement("div")
        hpBar.classList.add("hp-bar")

        hpContainer.classList.add("hp-bar-container")
        hpContainer.appendChild(hpBar)

        const arena = document.querySelector(".arena");
        arena.appendChild(hpContainer)
        hpContainer.style.top = (this.y - 20) + "px"
        hpContainer.style.left = this.x + 30 + "px"
        this.hpBar = hpBar;
    }

    createExpBar(){
        const expContainer = document.createElement("div")
        const expBar = document.createElement("div")
        expBar.classList.add("exp-bar")

        expContainer.classList.add("exp-bar-container")
        expContainer.appendChild(expBar)

        const arena = document.querySelector(".arena");
        arena.appendChild(expContainer)
        this.expBar = expBar;
    }

    detectHitListener = (e) => {    
        const charmanderElement = e.target;
        if (this.hp > 0) {
            new Audio('../entities/enemies/charmander/assets/ouch.mp3').play()
            this.hp--
            this.hpBar.style.width = (this.hp * 10) + "%"
            charmanderElement.style.transform = "scale(1.5)"
            setTimeout(() => {
                charmanderElement.style.transform = "scale(1)"
            }, 50);
        }
        if (this.hp === 0) {
            charmanderElement.src = "../entities/enemies/charmander/assets/die.gif"
            new Audio('../entities/enemies/charmander/assets/die.mp3').play()
            this.hpBar.parentElement.remove()
            this.hpBar.remove()
            charmanderElement.removeEventListener("click", this.detectHitListener)
            setTimeout(() => {
                charmanderElement.remove()

            }, 500);

        }
    }
    detectHit(charmanderElement) {
        charmanderElement.addEventListener("click", this.detectHitListener)
    }
            
    }

export default Charmander;