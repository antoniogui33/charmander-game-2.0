class Attributes {
    constructor(hp, atk, def, level) {
        this.hp = hp;
        this.atk = atk;
        this.def = def;
        this.levle = level;
    }
}

