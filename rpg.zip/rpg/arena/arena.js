class Arena {
    width = "100vw";
    height = "100vh";

    createCssLink() {
        const linkTag = document.createElement("link")
        linkTag.rel = "stylesheet"
        linkTag.href = "../arena/arena.css"
        const head = document.querySelector("head")
        head.appendChild(linkTag);
        return linkTag;
    }
    
    createArena() {
        this.createCssLink()
        const arenaElement = document.createElement("div");     
        arenaElement.style.height = this.height;
        arenaElement.style.width = this.width;
        arenaElement.classList.add("arena")
        const body = document.querySelector("body");
        body.appendChild(arenaElement);
        return arenaElement;
    }
}


export default Arena